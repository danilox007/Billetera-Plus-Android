# Billetera Plus
Proyecto Android para compilar un APK de prueba mediante GitHub Actions.

## Funciones
- Registro local de tarjetas de crédito y débito.
- Registro de cuotas, pagos y fechas de vencimiento.
- Pestaña de efectivo y transferencias internas entre efectivo y tarjetas.
- Movimientos y valores en pesos chilenos (CLP).
- Los datos se guardan localmente en el dispositivo; no hay sincronización en la nube ni notificaciones Android nativas.

## Compilar
En GitHub, abre Actions y ejecuta **Build Billetera Plus APK**. Al terminar correctamente, descarga el artefacto `BilleteraPlus-debug-apk`; dentro estará `app-debug.apk`.

No ingreses PIN, CVV ni claves bancarias. Esta aplicación no se conecta a bancos.
